class Clients < ActiveRecord::Migration[5.0]
  def self.up

	create_table :clients do |t|
		t.column :name, :string
	end
	
	Client.create :name => "Root"
	Client.create :name => "User1"
	Client.create :name => "User2"

   end

   def self.down
	drop_table :clients
   end
end
