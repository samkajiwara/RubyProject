class Server < ApplicationRecord
end
