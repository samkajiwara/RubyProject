class Script < ApplicationRecord
	belongs_to :client
	validates_presence_of :script, :message=>"Script Validator Error"
end
