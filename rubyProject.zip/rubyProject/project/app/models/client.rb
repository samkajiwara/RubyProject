class Client < ApplicationRecord
	has_many :scripts
end
