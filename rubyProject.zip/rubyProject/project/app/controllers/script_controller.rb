class ScriptController < ApplicationController
	def list
		@scripts = Script.all
	end

	def show
	end

	def new
	end

	def create
	end

	def edit
	end

	def update
	end

	def delete
	end


end
