module ScriptHelper
end
